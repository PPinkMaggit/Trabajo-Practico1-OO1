package test;

import java.time.LocalDate;

import modelo.Sistema;

public class Test {

	public static void main(String[] args) {
		
		Sistema s = new Sistema();
		
		s.agregarCocinero(11111111, "Juan", "Perez", LocalDate.of(1999, 3, 6), LocalDate.of(2023, 2, 20),100000, "Panaderia",20000);
		
		s.agregarCajero(22222222, "Alejo", "Gonzalez", LocalDate.of(1999, 7, 28), LocalDate.of(2023, 2, 20), 100000, "Mañana");
		
		System.out.println(s.buscarPersonal(22222222));
		System.out.println("$" + s.buscarPersonal(22222222).calcularLiquidacion()); 
		
		System.out.println(s.buscarPersonal(11111111));
		System.out.println("$" + s.buscarPersonal(11111111).calcularLiquidacion()); 
		
		
		
		
		
		
		


	}

}
