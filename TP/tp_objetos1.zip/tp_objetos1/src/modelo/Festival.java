package modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Festival {
	private int id;
	private String nombre;
	private String temporada;
	private LocalDate fechaInicio;
	private LocalDate fechaFinal;
	private Costo costos;
	private List<UnidadVenta> listUnidades;
	
	
	public Festival(int id, String nombre, String temporada, LocalDate fechaInicio, LocalDate fechaFinal, Costo costos) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.temporada = temporada;
		this.fechaInicio = fechaInicio;
		this.fechaFinal = fechaFinal;
		this.costos = costos;
		this.listUnidades = new ArrayList<UnidadVenta>();
	}

	

	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getNombre() {
		return nombre;
	}



	public void setNombre(String nombre) {
		this.nombre = nombre;
	}



	public String getTemporada() {
		return temporada;
	}



	public void setTemporada(String temporada) {
		this.temporada = temporada;
	}



	public LocalDate getFechaInicio() {
		return fechaInicio;
	}



	public void setFechaInicio(LocalDate fechaInicio) {
		this.fechaInicio = fechaInicio;
	}



	public LocalDate getFechaFinal() {
		return fechaFinal;
	}



	public void setFechaFinal(LocalDate fechaFinal) {
		this.fechaFinal = fechaFinal;
	}



	public Costo getCostos() {
		return costos;
	}



	public void setCostos(Costo costos) {
		this.costos = costos;
	}


	
	public List<UnidadVenta> getListUnidades() {
		return listUnidades;
	}



	@Override
	public String toString() {
		return "Festival [id=" + id + ", nombre=" + nombre + ", temporada=" + temporada + ", fechaInicio=" + fechaInicio
				+ ", fechaFinal=" + fechaFinal + ", costos=" + costos + ", listUnidades=" + listUnidades + "]";
	}



	public boolean equals(Festival f) {
		return nombre.equals(f.getNombre());
	}
	
	
	
	
}
