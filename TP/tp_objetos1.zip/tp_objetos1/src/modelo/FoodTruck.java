package modelo;

public class FoodTruck extends UnidadVenta {
	
	private String patente;
	private boolean usaElectricidad;
	
	public FoodTruck(int id, String codigo, String nombreComercial, Personal responsable, double superficie,String patente, boolean usaElectricidad) {
		super(id,codigo,nombreComercial,responsable,superficie);
		this.patente = patente;
		this.usaElectricidad = usaElectricidad;
	}

	public String getPatente() {
		return patente;
	}

	public void setPatente(String patente) {
		this.patente = patente;
	}

	public boolean isUsaElectricidad() {
		return usaElectricidad;
	}

	public void setUsaElectricidad(boolean usaElectricidad) {
		this.usaElectricidad = usaElectricidad;
	}

	@Override
	public String toString() {
		return "\nFoodTruck" + super.toString() + " [patente=" + patente + ", usaElectricidad=" + usaElectricidad + "]\n";
	}
	
	
	
	
	
	

}
