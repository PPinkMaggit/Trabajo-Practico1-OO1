package modelo;

public class Costo {
	private double costoSuperficie;
	private double costoMontaje;
	private double plusElectricidad;
	private double costoSueldoBase;

	public Costo(double costoSuperficie, double costoMontaje, double plusElectricidad, double costoSueldoBase) {
		super();
		this.costoSuperficie = costoSuperficie;
		this.costoMontaje = costoMontaje;
		this.plusElectricidad = plusElectricidad;
		this.costoSueldoBase = costoSueldoBase;
	}
	
	

	public double getCostoSuperficie() {
		return costoSuperficie;
	}



	public void setCostoSuperficie(double costoSuperficie) {
		this.costoSuperficie = costoSuperficie;
	}



	public double getCostoMontaje() {
		return costoMontaje;
	}



	public void setCostoMontaje(double costoMontaje) {
		this.costoMontaje = costoMontaje;
	}



	public double getPlusElectricidad() {
		return plusElectricidad;
	}



	public void setPlusElectricidad(double plusElectricidad) {
		this.plusElectricidad = plusElectricidad;
	}



	public double getCostoSueldoBase() {
		return costoSueldoBase;
	}



	public void setCostoSueldoBase(double costoSueldoBase) {
		this.costoSueldoBase = costoSueldoBase;
	}

	
	@Override
	public String toString() {
		return "\nCosto [costoSuperficie=" + costoSuperficie + ", costoMontaje=" + costoMontaje + ", plusElectricidad="
				+ plusElectricidad + ", costoSueldoBase=" + costoSueldoBase + "]\n";
	}

}
