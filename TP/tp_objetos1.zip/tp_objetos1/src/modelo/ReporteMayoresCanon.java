package modelo;

public class ReporteMayoresCanon {
	private UnidadVenta unidadVenta;
	private double canon;
	
	public ReporteMayoresCanon(UnidadVenta unidadVenta, double canon) {
		this.unidadVenta = unidadVenta;
		this.canon = canon;
	}


	public UnidadVenta getUnidadVenta() {
		return unidadVenta;
	}


	public void setUnidadVenta(UnidadVenta unidadVenta) {
		this.unidadVenta = unidadVenta;
	}


	public double getCanon() {
		return canon;
	}


	public void setCanon(double canon) {
		this.canon = canon;
	}
	
	
	
	

}
