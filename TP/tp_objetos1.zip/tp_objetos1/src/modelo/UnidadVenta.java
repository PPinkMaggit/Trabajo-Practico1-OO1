package modelo;

import java.util.ArrayList;
import java.util.List;

public abstract class UnidadVenta {
	protected int id;
	protected String codigo;
	protected String nombreComercial;
	protected Personal responsable;
	protected double superficie;
	protected List<Plato> listPlatos;
	protected List<Personal> listPersonal;
	
	public UnidadVenta(int id, String codigo, String nombreComercial, Personal responsable, double superficie) {
		super();
		this.id = id;
		this.codigo = codigo;
		this.nombreComercial = nombreComercial;
		this.responsable = responsable;
		this.superficie = superficie;
		this.listPlatos = new ArrayList<Plato>();
		this.listPersonal = new ArrayList<Personal>();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNombreComercial() {
		return nombreComercial;
	}

	public void setNombreComercial(String nombreComercial) {
		this.nombreComercial = nombreComercial;
	}

	public Personal getResponsable() {
		return responsable;
	}

	public void setResponsable(Personal responsable) {
		this.responsable = responsable;
	}

	public double getSuperficie() {
		return superficie;
	}

	public void setSuperficie(double superficie) {
		this.superficie = superficie;
	}
	
	
	public List<Plato> getListPlatos() {
		return listPlatos;
	}

	
	public List<Personal> getListPersonal() {
		return listPersonal;
	}


	@Override
	public String toString() {
		return "\nUnidadVenta [id=" + id + ", codigo=" + codigo + ", nombreComercial=" + nombreComercial + ", superficie="
				+ superficie + "]\n";
	}
	
	public boolean equals(UnidadVenta uVenta) {
		return codigo.equals(uVenta.getCodigo());
		
	}
	

	

}
