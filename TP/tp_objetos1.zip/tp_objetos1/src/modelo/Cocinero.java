package modelo;

import java.time.LocalDate;

public class Cocinero extends Personal {

	private String especialidad;
	private double plusFijo;
	
	public Cocinero(int id, long dni, String nombre, String apellido, LocalDate fechaNacimiento, LocalDate fechaIngreso,
			double sueldoBase,String especialidad, double plusFijo) {
		super(id,dni,nombre,apellido,fechaNacimiento,fechaIngreso,sueldoBase);
		this.especialidad = especialidad;
		this.plusFijo = plusFijo;
	}

	public String getEspecialidad() {
		return especialidad;
	}

	public void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}

	public double getPlusSueldo() {
		return plusFijo;
	}

	public void setPlusSueldo(double plusSueldo) {
		this.plusFijo = plusSueldo;
	}

	@Override
	public String toString() {
		return "\nCocinero" + super.toString() + "[especialidad=" + especialidad + ", plusSueldo=" + plusFijo + "]\n";
	}

	
	//CASO DE USO N4
	@Override
	public double calcularLiquidacion() {
		return getSueldoBase() + plusFijo;
	}
	
	
	
	                                         
	

}
