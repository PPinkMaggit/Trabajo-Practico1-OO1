package modelo;

import java.time.LocalDate;

public class Cajero extends Personal {
	
	private String turno;

	public Cajero(int id, long dni, String nombre, String apellido, LocalDate fechaNacimiento, LocalDate fechaIngreso,
			double sueldoBase,String turno) {
		super(id,dni,nombre,apellido,fechaNacimiento,fechaIngreso,sueldoBase);
		this.turno = turno;
	}
	                  

	public String getTurno() {
		return turno;
	}



	public void setTurno(String turno) {
		this.turno = turno;
	}



	@Override
	public String toString() {
		return "\nCajero" + super.toString() + "[turno=" + turno + "]\n";
	}

	//CASO DE USO N4
	@Override
	public double calcularLiquidacion() {
		return getSueldoBase() + (calcularAntiguedad() * 5000);
	}
	
	

}
