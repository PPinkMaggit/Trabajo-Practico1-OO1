/**
 * 
 */
/**
 * 
 */
module tp_objetos1 {
}