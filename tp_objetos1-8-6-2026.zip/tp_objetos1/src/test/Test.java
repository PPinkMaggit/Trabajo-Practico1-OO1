package test;

import java.time.LocalDate;


import modelo.Personal;
import modelo.Sistema;

public class Test {

	public static void main(String[] args) {
		
		Sistema s = new Sistema();
		
		s.agregarCocinero(11111111, "Juan", "Perez", LocalDate.of(1999, 3, 6), LocalDate.of(2023, 2, 20),100000, "Panaderia",20000);
		
		s.agregarCajero(22222222, "Alejo", "Gonzalez", LocalDate.of(1999, 7, 28), LocalDate.of(2023, 2, 20), 100000, "Mañana");
		
		System.out.println(s.buscarPersonal(22222222));
		System.out.println("$" + s.buscarPersonal(22222222).calcularLiquidacion()); 
		
		System.out.println(s.buscarPersonal(11111111));
		System.out.println("$" + s.buscarPersonal(11111111).calcularLiquidacion()); 
		
		s.agregarCajero(41000011, "Fernando", "Lopez", LocalDate.of(1999, 7, 25), LocalDate.of(2023,9, 21), 500, "Tarde");
		s.agregarCajero(41000022, "Camila", "Alvarez", LocalDate.of(1999, 2, 21), LocalDate.of(2023,5, 21), 500, "Tarde");
		s.agregarCajero(41000033, "Rosalia", "Lopez", LocalDate.of(1998, 3, 2), LocalDate.of(2023,4, 21), 500, "Noche");
		s.agregarCocinero(39000111, "Juan Carlos", "Solis", LocalDate.of(1998, 6, 3), LocalDate.of(2021, 3, 21), 600, "Sushi", 200);
		s.agregarCocinero(39000222, "Rogelio", "Buendia", LocalDate.of(1997, 5, 3), LocalDate.of(2023, 6, 17), 600, "Parrilla", 200);
		
		s.agregarPuestoDesmontable("COD111", "Los Hermanos S.A",s.buscarPersonal(41000000), 30, 3, 4);
		s.agregarFoodTruck("COD212", "PixHelados", s.buscarPersonal(41000033), 6, "AUH1666", true);
		
		s.agregarFestivales("Festival Del Pomelo", "Verano", LocalDate.of(2020,1,21),LocalDate.of(2024, 1, 28),null, null);
		s.agregarFestivales("Festival del queso rayado", "Verano",LocalDate.of(2020,1, 28),LocalDate.of(2024,2,3),null,null);
		

		System.out.println("Cantidad de personal filtrado: " + s.personalFiltrado(LocalDate.of(1998, 1, 1), LocalDate.of(1999, 7, 25)).size());

		for (Personal p : s.personalFiltrado(LocalDate.of(1998, 1, 1), LocalDate.of(1999, 7, 25))) {
		    System.out.println("- " + p.getNombre() + " (Nació el: " + p.getFechaNacimiento() + ")");
		}
		
		System.out.println("Lista Personal: "+ s.getlistPersonal());
		
		


	}

}
