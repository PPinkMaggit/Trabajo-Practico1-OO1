package modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Sistema {
	private List<Pedido> listPedidos;
	private List<UnidadVenta> listUnidades;
	private List<Personal> listPersonal;
	private List<Festival> listFestivales;
	
	
	public Sistema() {
		super();
		this.listUnidades=new ArrayList<UnidadVenta>();
		this.listPersonal= new ArrayList<Personal>();
		this.listFestivales = new ArrayList <Festival>();
		this.listPedidos = new ArrayList <Pedido>();
	}
	
	public List<Personal> getlistPersonal() {
		return listPersonal;
	}
	public List<UnidadVenta> getlistUnidadesVenta() {
		return listUnidades;
	}
	public List<Festival> getlistFestivales(){
		return listFestivales;
	}
	public List <Pedido> getlistPedidos(){
		return listPedidos;
	}
	
	
	//CASO DE USO N1
	public boolean agregarCajero(long dni, String nombre, String apellido, LocalDate fechaNacimiento, LocalDate fechaIngreso,
			double sueldoBase,String turno) {
		
		int id;
		
		if(!listPersonal.isEmpty()) {
			id = listPersonal.get(listPersonal.size() -1).getId() +1;
		} else {
			id = 1;
		}
		
		
		Personal p = new Cajero(id,dni,nombre,apellido,fechaNacimiento,fechaIngreso,
				sueldoBase,turno);
		
		
		
		return listPersonal.add(p);
	}
	
	public boolean agregarCocinero(long dni, String nombre, String apellido, LocalDate fechaNacimiento, LocalDate fechaIngreso,
			double sueldoBase,String especialidad, double plusFijo) {
		
		int id;
		
		if(!listPersonal.isEmpty()) {
			id = listPersonal.get(listPersonal.size() -1).getId() +1;
		} else {
			id = 1;
		}
		
		Personal p = new Cocinero(id,dni,nombre,apellido,fechaNacimiento,fechaIngreso,sueldoBase,especialidad,plusFijo);
		
		
		return listPersonal.add(p);
	}
	public boolean agregarFoodTruck(String codigo, String nombreComercial, Personal responsable, double superficie, String patente, boolean usaElectricidad) {
		int id = 1;
		if (!this.listUnidades.isEmpty()) {
			id = this.listUnidades.get(this.listUnidades.size() - 1).getId() + 1;
		}
		UnidadVenta nuevoFoodTruck = new FoodTruck(id, codigo, nombreComercial, responsable, superficie, patente, usaElectricidad);
		return this.listUnidades.add(nuevoFoodTruck);
	}

	public boolean agregarPuestoDesmontable(String codigo, String nombreComercial, Personal responsable, double superficie, int cantidadCarpas, int tiempoMontaje) {
		int id = 1;
		if (!this.listUnidades.isEmpty()) {
			id = this.listUnidades.get(this.listUnidades.size() - 1).getId() + 1;
		}
		UnidadVenta nuevoPuesto = new PuestoDesarmable(id, codigo, nombreComercial, responsable, superficie, cantidadCarpas, tiempoMontaje);

		return this.listUnidades.add(nuevoPuesto);
	}
	
	public boolean agregarFestivales(String nombre, String temporada, LocalDate fechaInicio, LocalDate fechaFinal, UnidadVenta listUnidadVenta,Costo listCosto) { //en parametros agregar los datos del festival
		int id = 1; 

		if (!this.listFestivales.isEmpty()){
			id = this.listFestivales.get(this.listFestivales.size()-1).getId()+1;	
		}
		Festival nuevoFestival = new Festival(id, nombre, temporada, fechaInicio, fechaFinal, listCosto);
		return listFestivales.add(nuevoFestival); 
	}
	
	
	//CASO DE USO N2
	public Personal buscarPersonal(long dni) {
	    Personal p = null;
	    
	    int i = 0;
	    
	    while (i < listPersonal.size() && p == null) {
	        if (listPersonal.get(i).getDni() == dni) {
	            p = listPersonal.get(i);
	        }
	        i++;
	    }
	    return p;
	}
	
	//CASO DE USO N2.1
	public UnidadVenta buscarUnidad(String codigo) {
		UnidadVenta u = null;
		int i = 0;
		
		while (i < listUnidades.size() && u == null) {
			if (listUnidades.get(i).getCodigo().equals(codigo)) {
				u = listUnidades.get(i);
			}
			i++;
		}
		return u;
	}
	
	//CASO DE USO N2.2
	public Festival buscarFestival(String nombre) {
		Festival f = null;
		int i = 0;
		
		while (i < listFestivales.size() && f == null) {
			if (listFestivales.get(i).getNombre().equals(nombre)) {
				f = listFestivales.get(i);
			}
			i++;
		}
		return f;
	}
	
	//CASO DE USO N2.3 (**IGNORAR**)
	public Pedido buscarPedido(String nombre ,String codigo) {
		Pedido p = null;
		int i = 0;
		
		while(i < listPedidos.size() && p == null) {
			if(listPedidos.get(i).getFestivalOcurrido().getNombre().equalsIgnoreCase(nombre) && listPedidos.get(i).getUnidadVenta().getCodigo().equalsIgnoreCase(codigo)) {
				p = listPedidos.get(i);
			}
			i++;
		}
		
		return p;
	}
	
	
	//CASO DE USO N5
	public boolean agregarPedido(LocalDate fechaTransaccion, Festival festivalOcurrido,UnidadVenta unidadVenta, List<ItemPedido> listItems) 
			throws Exception {
		if(buscarUnidad(unidadVenta.getCodigo()) == null || buscarFestival(festivalOcurrido.getNombre()) == null) {
			throw new Exception("Excepcion: La unidad o el festival no existe");
		}
		
        int id = 1;

        if (!this.listPedidos.isEmpty())
            id = this.listPedidos.get(this.listPedidos.size() - 1).getId() + 1;

        Pedido pedido = new Pedido(id,fechaTransaccion, festivalOcurrido,unidadVenta,listItems);
        return this.listPedidos.add(pedido);
                
    }
	
	//CU 6 
	public List<ReporteVenta> generarReporteRecaudacion(Festival festival) {
		List<ReporteVenta> reporteFinal = new ArrayList<>();

		for (UnidadVenta unidad : this.listUnidades) {

			double sumaRecaudacion = 0.0;

			for (Pedido pedido : this.listPedidos) {

				if (festival.equals(pedido.getFestivalOcurrido()) && pedido.getUnidadVenta().equals(unidad)) {
					sumaRecaudacion = sumaRecaudacion + pedido.totalPedido();
				}
			}

			ReporteVenta unReporte = new ReporteVenta(unidad, sumaRecaudacion);
			reporteFinal.add(unReporte);
		}
		return reporteFinal;
	}
	
	//CU 7
	public List<Personal> personalFiltrado(LocalDate fecha1, LocalDate fecha2){
		List<Personal> aux = new ArrayList<>();

		for (Personal p : listPersonal) {
			if (p.getFechaNacimiento().isAfter(fecha1) && p.getFechaNacimiento().isBefore(fecha2))  {
				aux.add(p);
			}
		}
		return aux;
	}
	
	//CU 11
	public Plato platoEstrella(UnidadVenta unidad, Festival festival) {

		List<Plato> platosAux = new ArrayList<>();

		for (Pedido pedido : listPedidos) {
			if (unidad.equals(pedido.getUnidadVenta()) && festival.equals(pedido.getFestivalOcurrido())) {
				for (ItemPedido item : pedido.getListItems()) {
					Plato p = item.getPlato();

					if (!platosAux.contains(p)) {
						platosAux.add(p);
					}
				}
			}
		}
		Plato platoEstrella = null;
		int maxCantidad = 0; 

		for (Plato platoActual : platosAux) {
			int cantidadTotalPlatos = 0;

			for (Pedido pedido : listPedidos) {
				if (unidad.equals(pedido.getUnidadVenta()) && festival.equals(pedido.getFestivalOcurrido())) {
					for (ItemPedido item : pedido.getListItems()) {
						if (item.getPlato().equals(platoActual)) {
							cantidadTotalPlatos += item.getCantidad();
						}
					}
				}
			}	
			if (cantidadTotalPlatos > maxCantidad) {
				maxCantidad = cantidadTotalPlatos;
				platoEstrella = platoActual;
			}

		}

		return platoEstrella;	 
	}

}
