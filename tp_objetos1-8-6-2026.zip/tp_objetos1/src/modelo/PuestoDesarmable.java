package modelo;

public class PuestoDesarmable extends UnidadVenta{
	
	private int cantidadCarpas;
	private int tiempoMontaje;
	
	
	public PuestoDesarmable(int id, String codigo, String nombreComercial, Personal responsable, double superficie,int cantidadCarpas, int tiempoMontaje) {
		super(id,codigo,nombreComercial,responsable,superficie);
		this.cantidadCarpas = cantidadCarpas;
		this.tiempoMontaje = tiempoMontaje;
	}


	public int getCantidadCarpas() {
		return cantidadCarpas;
	}


	public void setCantidadCarpas(int cantidadCarpas) {
		this.cantidadCarpas = cantidadCarpas;
	}


	public int getTiempoMontaje() {
		return tiempoMontaje;
	}


	public void setTiempoMontaje(int tiempoMontaje) {
		this.tiempoMontaje = tiempoMontaje;
	}


	@Override
	public String toString() {
		return "\nPuestoDesarmable" + super.toString() + " [cantidadCarpas=" + cantidadCarpas + ", tiempoMontaje=" + tiempoMontaje + "]\n";
	}
	
	//C.U 3
	@Override
	public double calculoDeCanon() {
		double canon = (getSuperficie() * 500) - (getTiempoMontaje()*10);
		return canon;
	}
	
}
